package com.app.gemstoneschool.interfaces;

public interface TotalListnerInterface {
    void onItemView(int position);
    void onItemClick(int position);

}
