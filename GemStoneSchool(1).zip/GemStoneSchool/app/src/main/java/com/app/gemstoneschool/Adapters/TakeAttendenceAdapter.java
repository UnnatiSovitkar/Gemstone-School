package com.app.gemstoneschool.Adapters;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.app.gemstoneschool.Activities.APINewsDetail;
import com.app.gemstoneschool.Activities.AttendenceShowStdList;
import com.app.gemstoneschool.Model.ActivityModel;
import com.app.gemstoneschool.Model.TakeAttendenceModel;
import com.app.gemstoneschool.NoticeRecycler.NewsModel;
import com.app.gemstoneschool.R;
import com.bumptech.glide.Glide;

import org.htmlcleaner.CleanerProperties;
import org.htmlcleaner.HtmlCleaner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class TakeAttendenceAdapter extends RecyclerView.Adapter<TakeAttendenceAdapter.ViewHolder> {

    List<TakeAttendenceModel> userlist = new ArrayList<>();

    Context context;
    public TakeAttendenceAdapter(Context context, List<TakeAttendenceModel>userlist){
        this.userlist=userlist;
        this.context=context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_takeattendence_item_design,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.className.setText("Class : "+userlist.get(position).getClassname());
        String clnm=userlist.get(position).getClassname();
        String id=userlist.get(position).getClassid().toString();

        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        String yr=String.valueOf(year);

        holder.viewclass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(v.getContext(), AttendenceShowStdList.class);
                intent.putExtra("className",clnm);
                intent.putExtra("ClassId",id);
                intent.putExtra("Year",yr);

                v.getContext().startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return userlist.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView className;
        private CardView viewclass;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            className=itemView.findViewById(R.id.tkatt);
            viewclass=itemView.findViewById(R.id.cardlayoutatt);

        }

    }
}
