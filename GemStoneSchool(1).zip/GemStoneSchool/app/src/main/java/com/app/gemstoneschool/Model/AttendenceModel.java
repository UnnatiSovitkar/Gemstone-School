package com.app.gemstoneschool.Model;

public class AttendenceModel {
    private int att_id,inst_id,user_type,class_id,board_id,sec_id,ay_id,admission_id,stud_att_status;
    private String att_status,leave_reason,stud_att_date,created_at,updated_at;

    public AttendenceModel(int att_id, int inst_id, int user_type,
                           int class_id, int board_id, int sec_id,
                           int ay_id, int admission_id,
                           String att_status, String leave_reason,
                           String stud_att_date,int stud_att_status,
                           String created_at,
                           String updated_at) {
        this.att_id = att_id;
        this.inst_id = inst_id;
        this.user_type = user_type;
        this.class_id = class_id;
        this.board_id = board_id;
        this.sec_id = sec_id;
        this.ay_id = ay_id;
        this.admission_id = admission_id;
        this.att_status = att_status;
        this.leave_reason = leave_reason;
        this.stud_att_date = stud_att_date;
        this.stud_att_status = stud_att_status;
        this.created_at = created_at;
        this.updated_at = updated_at;
    }

    public int getAtt_id() {
        return att_id;
    }

    public void setAtt_id(int att_id) {
        this.att_id = att_id;
    }

    public int getInst_id() {
        return inst_id;
    }

    public void setInst_id(int inst_id) {
        this.inst_id = inst_id;
    }

    public int getUser_type() {
        return user_type;
    }

    public void setUser_type(int user_type) {
        this.user_type = user_type;
    }

    public int getClass_id() {
        return class_id;
    }

    public void setClass_id(int class_id) {
        this.class_id = class_id;
    }

    public int getBoard_id() {
        return board_id;
    }

    public void setBoard_id(int board_id) {
        this.board_id = board_id;
    }

    public int getSec_id() {
        return sec_id;
    }

    public void setSec_id(int sec_id) {
        this.sec_id = sec_id;
    }

    public int getAy_id() {
        return ay_id;
    }

    public void setAy_id(int ay_id) {
        this.ay_id = ay_id;
    }

    public int getAdmission_id() {
        return admission_id;
    }

    public void setAdmission_id(int admission_id) {
        this.admission_id = admission_id;
    }

    public int getStud_att_status() {
        return stud_att_status;
    }

    public void setStud_att_status(int stud_att_status) {
        this.stud_att_status = stud_att_status;
    }

    public String getAtt_status() {
        return att_status;
    }

    public void setAtt_status(String att_status) {
        this.att_status = att_status;
    }

    public String getLeave_reason() {
        return leave_reason;
    }

    public void setLeave_reason(String leave_reason) {
        this.leave_reason = leave_reason;
    }

    public String getStud_att_date() {
        return stud_att_date;
    }

    public void setStud_att_date(String stud_att_date) {
        this.stud_att_date = stud_att_date;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setCreated_at(String created_at) {
        this.created_at = created_at;
    }

    public String getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(String updated_at) {
        this.updated_at = updated_at;
    }
}
