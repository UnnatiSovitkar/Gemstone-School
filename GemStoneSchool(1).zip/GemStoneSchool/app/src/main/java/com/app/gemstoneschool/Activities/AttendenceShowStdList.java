package com.app.gemstoneschool.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.app.gemstoneschool.Adapters.AttStdListAdapter;
import com.app.gemstoneschool.Adapters.TakeAttendenceAdapter;
import com.app.gemstoneschool.Model.AttStdListModel;
import com.app.gemstoneschool.Model.TakeAttendenceModel;
import com.app.gemstoneschool.R;
import com.bumptech.glide.load.model.Model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AttendenceShowStdList extends AppCompatActivity {

    Toolbar toolbar;
    String name,id,date,yr;
    ArrayList<AttStdListModel> userlist = new ArrayList<>();
    List<AttStdListModel> list=new ArrayList<AttStdListModel>();
    AttStdListAdapter adapter;
    Button sbmt;

    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //disable screenshot
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//full screen
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);//full screen

        setContentView(R.layout.activity_attendence_show_std_list);
        sbmt =findViewById(R.id.smt);

        //getting data from TakeAttendenceAdapter cardview
        name=getIntent().getExtras().getString("className");
        id=getIntent().getExtras().getString("ClassId");
        Log.d("cliddd",id);
        yr=getIntent().getExtras().getString("Year");

        Log.d("yrrr",yr);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        date = sdf.format(new Date());
        Log.d("dttt",date);

        recyclerView =findViewById(R.id.rvstdlist);

        userlist = (ArrayList<AttStdListModel>) getModel(false);
        adapter = new AttStdListAdapter(this,userlist);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));




//        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
//        recyclerView.setHasFixedSize(true);

        getData();


        //toolbar
        toolbar=findViewById(R.id.toolbarstdlist);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        sbmt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AttendenceShowStdList.this,SubmitAttendenceActivity.class);
                startActivity(intent);
            }
        });


    }
    private List<AttStdListModel> getModel(boolean isSelect){
        List<AttStdListModel> list = new ArrayList<>();
        for(int i = 0; i < list.size(); i++){

            AttStdListModel model = new AttStdListModel();
            model.setSelected(isSelect);
            model.setStud_name(String.valueOf(list.get(i)));
            model.setSr_id(String.valueOf(list.get(i)));
            list.add(model);
        }
        return list;
    }
    private void getData() {
        RequestQueue queue = Volley.newRequestQueue(getApplicationContext());
        String url1="https://gemstonews.in/gemstoneerp/apis/teacher/get_studteachers_att.php";


        StringRequest request = new StringRequest(Request.Method.POST, url1, new com.android.volley.Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.d("ClassDetails",response);

                //  Toast.makeText(getContext(), "Data added to API", Toast.LENGTH_SHORT).show();
                try {

                    JSONObject respObj = new JSONObject(response);

                    JSONArray jsonArray5=respObj.getJSONArray("studatt_details");

                    Log.d("std details",jsonArray5.toString());
                    for(int i=0;i<jsonArray5.length();i++){
                        JSONObject jsonObject=jsonArray5.getJSONObject(i);
                        String sr_id=jsonObject.optString("sr_id");
                        Log.d("cliddd",id);
                        String stud_name=jsonObject.optString("stud_name");
                        String stud_phone=jsonObject.optString("stud_phone");
                        String stud_email=jsonObject.optString("stud_email");
                        String attd_status=jsonObject.optString("attd_status");
                        String attd_reason=jsonObject.optString("attd_reason");

                        userlist.add(new AttStdListModel(sr_id,stud_name,stud_phone,stud_email,
                                attd_status,attd_reason));
                        Log.d("s", String.valueOf(userlist));


                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                adapter=new AttStdListAdapter(getApplicationContext(),userlist);
                recyclerView.setAdapter(adapter);
                adapter.notifyDataSetChanged();

            }
        }, new com.android.volley.Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Toast.makeText(getApplicationContext(), "Fail to get response = " + error, Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();


                params.put("get_studattd","1");
                params.put("class_id",id);
                params.put("ay_id","23");
                params.put("stud_attend_date","2022-10-07");


                return params;
            }
        };

        queue.add(request);
    }

    //toolbar back to home
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()==android.R.id.home){

            finish();
        }
        return super.onOptionsItemSelected(item);
    }

}