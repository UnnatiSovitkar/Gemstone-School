package com.app.gemstoneschool.Model;

public class TakeAttendenceModel {
    private String classid, classname;

    public TakeAttendenceModel(String classid, String classname) {
        this.classid = classid;
        this.classname = classname;
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid;
    }

    public String getClassname() {
        return classname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }
}
