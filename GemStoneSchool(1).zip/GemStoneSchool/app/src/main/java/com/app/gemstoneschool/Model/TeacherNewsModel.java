package com.app.gemstoneschool.Model;

public class TeacherNewsModel {
    private String id, title,description,date,news_image;
    public TeacherNewsModel(String id, String title, String description, String date, String news_image) {
        this.id = id;
        this.title=title;
        this.description = description;
        this.date = date;
        this.news_image=news_image;
    }

    public String getNews_image() {
        return news_image;
    }

    public void setNews_image(String news_image) {
        this.news_image = news_image;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDate() {
        return date;
    }


}
