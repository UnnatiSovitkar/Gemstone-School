package com.eg.gemstoneschool.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.eg.gemstoneschool.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class APINewsDetail extends AppCompatActivity {
    Toolbar toolbar1;

    TextView detailNews,dDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //disable screenshot
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_apinews_detail);

        detailNews=findViewById(R.id.news);
        dDate=findViewById(R.id.newsdate);

        //toolbar
        toolbar1=findViewById(R.id.toolbarnews);
        setSupportActionBar(toolbar1);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        detailNews.setText(getIntent().getExtras().getString("detail"));
        String dt=getIntent().getExtras().getString("dateformat");
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat formatterOut = new SimpleDateFormat("dd-MM-yyyy");


        try {

            Date date = formatter.parse(dt);
            System.out.println(date);
            dDate.setText(formatterOut.format(date));

        } catch (ParseException e) {
            e.printStackTrace();
        }
        //dDate.setText(getIntent().getExtras().getString("dateformat"));
    }
}