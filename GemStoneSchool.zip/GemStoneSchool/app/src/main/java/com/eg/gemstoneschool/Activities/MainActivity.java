package com.eg.gemstoneschool.Activities;

import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.eg.gemstoneschool.Dashbord;
import com.eg.gemstoneschool.R;
import com.eg.gemstoneschool.service.NetworkBroadcast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    Button Erase;
    EditText MobNo;
    RadioGroup rgb;
    RadioButton rb;

   private BroadcastReceiver broadcastReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //disable screenshot
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_main);

        Button Login=findViewById(R.id.login);
        Erase=findViewById(R.id.erase);
        MobNo=findViewById(R.id.mob_no);
        rgb=findViewById(R.id.loginrgb);

        //validation of mob no//

        //validation of mob//

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String number=MobNo.getText().toString();

                int sid=rgb.getCheckedRadioButtonId();
                rb=(RadioButton) findViewById(sid);
                if (sid==-1){
                    Toast.makeText(MainActivity.this, "Please select Option", Toast.LENGTH_LONG).show();
                }
                else{

                    boolean check=validateMobile(number);

                    if(check==true) {
                        Toast.makeText(MainActivity.this,
                                "Successfully Login", Toast.LENGTH_LONG).show();
                        Intent i = new Intent(getApplicationContext(), Dashbord.class);
                        startActivity(i);
                    }

                    Toast.makeText(MainActivity.this, rb.getText(), Toast.LENGTH_LONG).show();

                }


            }
        });

        Erase.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                MobNo.getText().clear();
            }
        });

        //no internet connection
        broadcastReceiver=new NetworkBroadcast();
        registerReceiver(broadcastReceiver,new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        //end no internet connection

    }
    protected void onDestroy() {
        super.onDestroy();
        unregisterReceiver(broadcastReceiver);
    }
    //validation of mob no//
    private boolean validateMobile(String number){
       if(number.length()==0){
           MobNo.requestFocus();
           MobNo.setError("field cannot be empty");
           return false;
       }else if(!number.matches("^[6-9][0-9]{9}$")) {
           MobNo.requestFocus();
           MobNo.setError("Invalid Mobile No");
           return false;
       }
       else {
           return true;
       }
    }
}