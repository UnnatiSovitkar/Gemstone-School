package com.eg.gemstoneschool;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import com.eg.gemstoneschool.fragments.Calenderfragment;
import com.eg.gemstoneschool.fragments.Contactusdrawerfragment;
import com.eg.gemstoneschool.fragments.DrawerFragmentAboutus;
import com.eg.gemstoneschool.fragments.Galleryfragment;
import com.eg.gemstoneschool.fragments.Homefragment;
import com.eg.gemstoneschool.fragments.Mefragment;
import com.eg.gemstoneschool.fragments.Remarkdrawerfragment;
import com.eg.gemstoneschool.fragments.Sendenquirydrawerfragment;
import com.eg.gemstoneschool.fragments.Summaryfragment;
import com.eg.gemstoneschool.fragments.Videosfragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;
import com.google.android.material.navigation.NavigationView;

public class Dashbord extends AppCompatActivity {

    Toolbar toolbar;
    DrawerLayout drawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashbord);

        //bottom navigation

        BottomNavigationView bottomNavigationView=findViewById(R.id.bottom_nav);
        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,new Homefragment()).commit();

        bottomNavigationView.setSelectedItemId(R.id.homebottom);

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment selectedfragment=null;

                switch (item.getItemId()){
                    case R.id.homebottom:
                        selectedfragment=new Homefragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectedfragment).commit();
                        break;
                    case R.id.gallarybottom:
                        selectedfragment=new Calenderfragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectedfragment).commit();
                        break;
                    case R.id.summarybottom:
                        selectedfragment=new Videosfragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectedfragment).commit();
                        break;

                    case R.id.sharebottom:
                        //selectedfragment=new Mefragment();
                        //getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectedfragment).commit();
                        //break;
                        try {

                            Intent intent=new Intent(Intent.ACTION_SEND);
                            intent.setType("text/plain");
                            intent.putExtra(Intent.EXTRA_SUBJECT,"Demo Share");
                            String sharemsg="https://play.google.com/store/apps/details?id="+BuildConfig.APPLICATION_ID+"\n\n";
                            intent.putExtra(Intent.EXTRA_TEXT,sharemsg);
                            startActivity(Intent.createChooser(intent,"share by"));

                        }catch (Exception e){
                            Toast.makeText(Dashbord.this, "Error occured", Toast.LENGTH_SHORT).show();

                        }
                }


                return true;
            }
        });

        //drawer navigation

        toolbar = findViewById(R.id.toolBar);
        drawer = findViewById(R.id.drawerlayout);
        NavigationView navigationView=findViewById(R.id.nav_view);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawer.openDrawer(GravityCompat.START);
            }
        });
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id=item.getItemId();
                drawer.closeDrawer(GravityCompat.START);
                Fragment selectfragment1=null;

                switch (id){
                    //case R.id.profiledrawer:
                      //  selectfragment1=new Mefragment();
                       // getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectfragment1).commit();
                        //Toast.makeText(Dashbord.this, "profile", Toast.LENGTH_LONG).show();
                        //break;
                    case R.id.homedrawer:
                        selectfragment1=new Homefragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectfragment1).commit();
                        //Toast.makeText(Dashbord.this, "Home", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.aboutschooldrawer:
                        selectfragment1=new DrawerFragmentAboutus();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectfragment1).commit();
                        //Toast.makeText(Dashbord.this, "About School", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.gallerydrawer:
                        selectfragment1=new Galleryfragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectfragment1).commit();
                        //Toast.makeText(Dashbord.this, "Gallary", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.activitydrawer:
                        selectfragment1=new Videosfragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectfragment1).commit();
                       // Toast.makeText(Dashbord.this, "Videos", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.feedbackdrawer:
                        selectfragment1=new Remarkdrawerfragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectfragment1).commit();
                        //Toast.makeText(Dashbord.this, "Remark", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.contactdrawer:
                        selectfragment1=new Contactusdrawerfragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectfragment1).commit();
                        //Toast.makeText(Dashbord.this, "Contact us", Toast.LENGTH_LONG).show();
                        break;
                    case R.id.senddrawer:
                        selectfragment1=new Sendenquirydrawerfragment();
                        getSupportFragmentManager().beginTransaction().replace(R.id.framecontainer,selectfragment1).commit();
                        //Toast.makeText(Dashbord.this, "Send Enquiry", Toast.LENGTH_LONG).show();
                        break;

                    case R.id.sharedrawer:
                        try {

                            Intent intent=new Intent(Intent.ACTION_SEND);
                            intent.setType("text/plain");
                            intent.putExtra(Intent.EXTRA_SUBJECT,"Demo Share");
                            String sharemsg="https://play.google.com/store/apps/details?id="+BuildConfig.APPLICATION_ID+"\n\n";
                            intent.putExtra(Intent.EXTRA_TEXT,sharemsg);
                            startActivity(Intent.createChooser(intent,"share by"));

                        }catch (Exception e){
                            Toast.makeText(Dashbord.this, "Error occured", Toast.LENGTH_SHORT).show();

                        }
                        break;
                    default:
                        return true;
                }

                return true;
            }
        });



    }
}